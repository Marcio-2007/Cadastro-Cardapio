Cadastro, recadastro e login dos funcionários para a pagina de integração de informações e organização de pedidos do cardapio virtual

cadastro/
├── css/
│   ├── cdt.css
│   ├── login.css
│   └── redef.css
├── img/
│   ├── aberto.png
│   ├── bg.png
│   ├── favicon.png
│   ├── luz-de-fundo.png
│   ├── lock.png
│   ├── logo.png
│   └── profile.png
├── user
│    └── perfil.json    //quando gerado
├── cdt.php
├── login.php
└── redef.php
























































