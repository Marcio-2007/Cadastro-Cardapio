<?php
	function redec(){
		header('location: sucessoteste.php');
		exit();
	}
	
	session_start();
		if ($_SERVER['REQUEST_METHOD'] == "POST") {
			
			$user = $_POST['user'];
			$pass = $_POST['pass'];

			$consulta = file_get_contents($_SESSION['caminho']);
			$jsonarq = json_decode($consulta, True);
			
			if($jsonarq['user'] == $user && password_verify($pass, $jsonarq['password'])) {
				redec();
			}
		}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/login.css">
	<link rel="shortcut icon" href="img/favicon.png" type="image/png">
</head>
<body>

	<aside id="background">
    </aside>
	
	<aside id="luz">
		<div id="logo">
			<img src="img/logo.png" alt="logo">
		</div>
	</aside>

    <main id="esq">
	
        <header id="header">
            <div id="title">
                <p>Login</p>
            </div>
        </header>

        <form action="" method="POST">
          
			<div class="campo">
				<div class="iconizinho">
					<img src="img/profile.png" alt="logo">
				</div>
				<input type="text" id="nm" name="user" placeholder="Nome" required/>
			</div>
			
			<div class="campo">
				<div class="iconizinho">
					<img id="clicker" src="img/lock.png" alt="fechado">
				</div>
				<input type="password" id="sh" name="pass" placeholder="Senha" required/>
			</div>

            <div id="botao">
				<a href="redef.php" target="_self">Redefinir Cadastro</a>
                <button>Confirmar</button>
            </div>

        </form>
    </main>

    <aside id="bck2">
    </aside>

	<script src="js/script.js"></script>
</body>
</html>