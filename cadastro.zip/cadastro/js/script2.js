let campo = document.querySelector("#nm2")
const senha2 = document.querySelector("#sh2")
const clicker2 = document.querySelector("#clicker2")

addEventListener('keyup', ()=>{
	let Crescer = campo.value
	Crescer = Crescer.toUpperCase()
	
	campo.value = Crescer
})

clicker2.addEventListener('click', ()=>{
	if (senha2.type === "password"){
		senha2.type = 'text'
		clicker2.src="img/aberto.png"
		clicker2.alt="aberto"
	}
	else{
		senha2.type = 'password'
		clicker2.src="img/lock.png" 
		clicker2.alt="fechado"
	}
})