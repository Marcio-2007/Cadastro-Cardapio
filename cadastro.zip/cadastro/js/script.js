let input = document.querySelector("#nm")
const senha = document.querySelector("#sh")
const clicker = document.querySelector("#clicker")

addEventListener('keyup', ()=>{
	let Crescer = input.value
	Crescer = Crescer.toUpperCase()
	
	input.value = Crescer
})

clicker.addEventListener('click', ()=>{
	if (senha.type === "password"){
		senha.type = 'text'
		clicker.src="img/aberto.png"
		clicker.alt="aberto"
	}
	else{
		senha.type = 'password'
		clicker.src="img/lock.png" 
		clicker.alt="fechado"
	}
})