Cadastro, recadastro e login dos funcionários para a pagina de integração de informações e organização de pedidos do cardapio virtual

cadastro/
├── config/
│   └── acesso.php
├── css/
│   ├── cdt.css
│   ├── login.css
│   └── redef.css
├── img/
│   ├── aberto.png
│   ├── bg.png
│   ├── favicon.png
│   ├── luz-de-fundo.png
│   ├── lock.png
│   ├── logo.png
│   └── profile.png
├── info/
│   └── README.md
├── js/
│   ├── script.js
│   └── script2.js
├── cdt.php
├──	sucessoteste.php	//Temporariamente
├── login.php
└── redef.php
























































