<?php
	$dsn = "mysql:dbname=cardapio;host=localhost;port=3306;";
	$us = "root";
	$ps = "";
	
	$modal = False;
	$cx = False;
	
	try{
		$pdo = new PDO($dsn, $us, $ps);
		
		if ($_SERVER['REQUEST_METHOD'] == "POST") {
			
			acao();
		}
	}
	
	catch(PDOException $e2) {
		$cx = True;
	}
	
	catch(Exception $e) {
		$modal = True;
	}
?>