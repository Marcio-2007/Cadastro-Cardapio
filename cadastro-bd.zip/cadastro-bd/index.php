<?php
	function redec(){
		header('location: login.php');
		exit();
	}
	
	$dsn = "mysql:dbname=cardapio;host=localhost;port=3306;";
	$us = "root";
	$ps = "";
	
	$nome = $_POST['usuario'] ?? '';
	$senha = $_POST['numeros'] ?? '';
	$cript = password_hash($senha, PASSWORD_BCRYPT);
	$modal = False;
	
	try{
		$pdo = new PDO($dsn, $us, $ps);
		
		if ($_SERVER['REQUEST_METHOD'] == "POST") {
			
			$s1 = $pdo->prepare("SELECT * FROM usuario WHERE nome = :nome;");
			$s1->execute(['nome' => $nome]);
			$stmt = $s1->fetch(PDO::FETCH_ASSOC);
			
			if($stmt == True) {
				throw new Exception();
			} 
			
			else {
				$insert = $pdo->prepare("INSERT INTO usuario (nome, senha) VALUES (:nome, :cript)");
				$insert->execute(['nome' => $nome, 'cript' => $cript]);
				redec();
			}
		}
	}
	
	catch(Exception $e) {
		echo $e->getMessage();
		$modal = True;
	}
	
	catch(PDOException $e2) {
		echo $e2->getMessage();
	}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro</title>
    <link rel="stylesheet" href="css/cdt.css">
	<link rel="shortcut icon" href="img/favicon.png" type="image/png">
</head>
<body>
	<?php
		if ($modal == True) {
			echo	'<dialog id="modal" open>';
			echo		'<div id="warn">';
			echo			'<p>Nome já existente.</p>';
			echo			'<form id="modal-form" method="dialog">';
			echo				'<button id="modal-bt">Fechar</button>';
			echo			'</form>';
			echo		'</div>';
			echo	'</dialog>';
		}
	?>
	<aside id="background">
    </aside>
	
	<aside id="luz">
		<div id="logo">
			<img src="img/logo.png" alt="logo">
		</div>
	</aside>

    <main id="esq">
	
        <header id="header">
            <div id="title">
                <p>Cadastro</p>
            </div>
            <div id="exp">
                <p>Essa etapa é necesária uma única vez, a menos que você deseje redefinir sua senha e nome de perfil.</p>
            </div>
        </header>

        <form method="POST" action="">

			<div class="campo">
				<div class="iconizinho">
					<img src="img/profile.png" alt="logo">
				</div>
				<label for="nm">Crie um nome de perfíl:</label>   
				<input type="text" id="nm" name="usuario" placeholder="Nome" maxlength="40" required/>
			</div>
			
			<div class="campo">
				<div class="iconizinho">
					<img id="clicker" src="img/lock.png" alt="fechado">
				</div>
				<label for="sh">Crie uma senha:</label>
				<input type="password" id="sh" name="numeros" placeholder="Senha" maxlength="20" required/>
            </div>
			
            <div id="botao">
				<a href="login.php" target="_self">Fazer Login</a>
                <button>Confirmar</button>
            </div>
            
        </form>
    </main>
	
	<aside id="bck2">
    </aside>

	<script src="js/script.js"></script>
</body>
</html>