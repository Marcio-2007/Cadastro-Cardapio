<?php
	include "config/acesso.php";
	
	function redec(){
		header('location: login.php');
		exit();
	}
	
	function acao() {
		global $pdo;
		
		$nome = $_POST['usuario'] ?? '';
		$senha = $_POST['numeros'] ?? '';
		$cript = password_hash($senha, PASSWORD_BCRYPT);
		
		$s1 = $pdo->prepare("SELECT * FROM usuario WHERE nome = :nome;");
		$s1->execute(['nome' => $nome]);
		$stmt = $s1->fetch(PDO::FETCH_ASSOC);
			
		if($stmt == True) {
			throw new Exception();
		} 
		
		else {
			$insert = $pdo->prepare("INSERT INTO usuario (nome, senha) VALUES (:nome, :cript)");
			$insert->execute(['nome' => $nome, 'cript' => $cript]);
			redec();
		}
	}
	
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro</title>
    <link rel="stylesheet" href="css/cdt.css">
	<link rel="shortcut icon" href="img/favicon.png" type="image/png">
</head>
<body>
	<?php
		if ($cx == True) {
			echo	'<dialog id="modal" open>';
			echo		'<aside id="fundo">';
			echo		'</aside>';
			echo		'<div id="warn">';
			echo			'<p>Conexão com o Banco de Dados não foi efetuada.</p>';
			echo		'</div>';
			echo	'</dialog>';
		}
	
		if ($modal == True) {
			echo	'<dialog id="modal" open>';
			echo		'<aside id="fundo">';
			echo		'</aside>';
			echo		'<div id="warn">';
			echo			'<p>Esse nome já existe.</p>';
			echo			'<form id="modal-form" method="dialog">';
			echo				'<button id="modal-bt">Fechar</button>';
			echo			'</form>';
			echo		'</div>';
			echo	'</dialog>';
		}
	?>
	<aside id="background">
    </aside>
	
	<aside id="luz">
		<div id="logo">
			<img src="img/logo.png" alt="logo">
		</div>
	</aside>

    <main id="esq">
	
        <header id="header">
            <div id="title">
                <p>Cadastro</p>
            </div>
            <div id="exp">
                <p>Essa etapa é necesária uma única vez, a menos que você deseje redefinir sua senha e nome de perfil.</p>
            </div>
        </header>

        <form method="POST" action="">

			<div class="campo">
				<div class="iconizinho">
					<img src="img/profile.png" alt="logo">
				</div>
				<label for="nm">Crie um nome de perfíl:</label>   
				<input type="text" id="nm" name="usuario" placeholder="Nome" maxlength="40" required/>
			</div>
			
			<div class="campo">
				<div class="iconizinho">
					<img id="clicker" src="img/lock.png" alt="fechado">
				</div>
				<label for="sh">Crie uma senha:</label>
				<input type="password" id="sh" name="numeros" placeholder="Senha" maxlength="20" required/>
            </div>
			
            <div id="botao">
                <button>Confirmar</button>
				<a href="login.php" target="_self">Fazer Login</a>
            </div>
            
        </form>
    </main>
	
	<aside id="bck2">
    </aside>

	<script src="js/script.js"></script>
</body>
</html>