<?php
	function redec(){
		header('location: login.php');
		exit();
	}
	
	$dsn = "mysql:dbname=cardapio;host=localhost;port=3306;";
	$us = "root";
	$ps = "";
	
	try {
		$pdo = new PDO($dsn, $us, $ps);
		
		if ($_SERVER['REQUEST_METHOD'] == "POST") {
			
			$olduser = $_POST['olduser'];
			$oldpass = $_POST['oldpass'];
			$newuser = $_POST['newuser'];
			$newpass = $_POST['newpass'];
			$hashpass = password_hash($newpass, PASSWORD_BCRYPT);
			
			$s1 = $pdo->prepare("SELECT * FROM usuario WHERE nome = :user;");
			$s1->execute(['user' => $olduser]);
			$arr = $s1->fetch(PDO::FETCH_ASSOC);
			
			if($arr == True && $arr['nome'] == $olduser && password_verify($oldpass, $arr['senha'])) {
				$up = $pdo->prepare("UPDATE usuario SET nome = :nome, senha = :senha WHERE id = :id");
				$up->execute(['nome' => $newuser, 'senha' => $hashpass, 'id' => $arr['id']]);
				redec();
			}
		}
	}
	catch(PDOExeption $e) {
		$e->getMessage();
	}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Redefinir cadastro</title>
    <link rel="stylesheet" href="css/redef.css">
	<link rel="shortcut icon" href="img/favicon.png" type="image/png">
</head>
<body>

	<aside id="background">
    </aside>
	
	<aside id="luz">
		<div id="logo">
			<img src="img/logo.png" alt="logo">
		</div>
	</aside>
	
    <main id="esq">
	
        <header id="header">
            <div id="title">
                <p>Redefinir Cadastro</p>
            </div>
            <div id="exp">
                <p>Para redefinir seu cadastro, insira seu nome e senha do cadastro atual. Após isso, siga com as novas credênciais.</p>
            </div>
        </header>

        <form action="" method="POST">

            <div class="linha">

                <div class="campo">
					<img class="img" src="img/profile.png" alt="logo">
                    <label for="nm">Nome de perfíl atual:</label>
                    <input type="text" id="nm" name="olduser" placeholder="Nome" required/>
                </div>


                <div class="campo">
					<img id="clicker" class="img" src="img/lock.png" alt="fechado">
                    <label for="sh">Senha atual:</label>
                    <input type="password" id="sh" name="oldpass" placeholder="Senha" required/> 
                </div>
            </div>

            <div class="linha">
                
                <div class="campo">
					<img class="img" src="img/profile.png" alt="logo">
                    <label for="nm2">Novo nome de perfíl:</label>
                    <input type="text" id="nm2" name="newuser" placeholder="Nome" required/>
                </div>


                <div class="campo">
					<img id="clicker2" class="img" src="img/lock.png" alt="fechado">
                    <label for="sh2">Nova senha:</label>
                    <input type="password" id="sh2" name="newpass" placeholder="Senha" required/>
                </div>
            </div>

			<div id="botao">
				<a href="login.php" target="_self">Voltar</a>
                <button>Confirmar</button>
            </div>
			
        </form>
    </main>
	
	<aside id="bck2">
    </aside>
      
	<script src="js/script.js"></script>
	<script src="js/script2.js"></script>
</body>
</html>